<?php 
	// Sometimes index files do not works.
?>